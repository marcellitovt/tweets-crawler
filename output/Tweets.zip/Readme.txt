PSHT	: 5855
Pendekar: 6079
Tamsis	: 1247